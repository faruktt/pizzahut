<?php $__env->startSection('title', 'Create Role'); ?>
<?php $__env->startSection('page-title', 'Create Role'); ?>

<?php $__env->startSection('admin-content'); ?>
<div style="max-width:960px;margin:0 auto;display:flex;flex-direction:column;gap:20px;">
    <!-- Back Link -->
    <a href="<?php echo e(route('admin.roles.index')); ?>" style="display:inline-flex;align-items:center;gap:6px;color:#64748b;text-decoration:none;font-size:0.85rem;font-weight:600;">
        <i class="fa-solid fa-arrow-left"></i> Back to Roles
    </a>

    <form method="POST" action="<?php echo e(route('admin.roles.store')); ?>" style="background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:26px;display:flex;flex-direction:column;gap:24px;">
        <?php echo csrf_field(); ?>

        <!-- Role Basic Info -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;">
            <div>
                <label style="display:block;font-size:0.82rem;font-weight:700;color:#334155;margin-bottom:6px;">Role Name *</label>
                <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="e.g. Kitchen Supervisor" required style="width:100%;padding:9px 12px;border:1px solid #cbd5e1;border-radius:8px;font-size:0.88rem;font-family:'Poppins',sans-serif;outline:none;">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color:#ef4444;font-size:0.75rem;margin-top:4px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label style="display:block;font-size:0.82rem;font-weight:700;color:#334155;margin-bottom:6px;">Description</label>
                <input type="text" name="description" value="<?php echo e(old('description')); ?>" placeholder="Brief description of this role's purpose" style="width:100%;padding:9px 12px;border:1px solid #cbd5e1;border-radius:8px;font-size:0.88rem;font-family:'Poppins',sans-serif;outline:none;">
            </div>
        </div>

        <!-- Master Select All -->
        <div style="border-top:1px solid #f1f5f9;padding-top:18px;display:flex;align-items:center;justify-content:space-between;">
            <h3 style="font-size:1.1rem;font-weight:800;color:#0f172a;margin:0;">Permissions</h3>
            <label style="display:inline-flex;align-items:center;gap:8px;font-size:0.82rem;font-weight:700;color:var(--admin-primary);cursor:pointer;user-select:none;">
                <input type="checkbox" id="masterSelectAll" onchange="toggleAllPermissions(this)" style="width:16px;height:16px;accent-color:var(--admin-primary);cursor:pointer;">
                Select All Permissions
            </label>
        </div>

        <!-- Modules Grid -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(280px, 1fr));gap:16px;">
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $modulePerms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;background:#fafafa;">
                    <!-- Module Header with Select All for this module -->
                    <div style="padding:10px 14px;background:#f1f5f9;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;">
                        <span style="font-weight:800;font-size:0.82rem;color:#0f172a;text-transform:uppercase;letter-spacing:0.3px;">
                            <?php echo e($module); ?>

                        </span>
                        <label style="display:inline-flex;align-items:center;gap:5px;font-size:0.72rem;color:#64748b;font-weight:600;cursor:pointer;">
                            <input type="checkbox" class="module-select-all" data-module="<?php echo e(Str::slug($module)); ?>" onchange="toggleModulePermissions(this, '<?php echo e(Str::slug($module)); ?>')" style="width:14px;height:14px;accent-color:var(--admin-primary);">
                            All
                        </label>
                    </div>

                    <!-- Module Checkboxes -->
                    <div style="padding:12px 14px;display:flex;flex-direction:column;gap:8px;background:#fff;">
                        <?php $__currentLoopData = $modulePerms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label style="display:flex;align-items:center;gap:9px;font-size:0.8rem;color:#334155;cursor:pointer;user-select:none;">
                                <input type="checkbox" name="permissions[]" value="<?php echo e($perm->id); ?>" class="perm-checkbox perm-module-<?php echo e(Str::slug($module)); ?>" style="width:15px;height:15px;accent-color:var(--admin-primary);cursor:pointer;">
                                <span><?php echo e($perm->name); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Form Submit -->
        <div style="border-top:1px solid #f1f5f9;padding-top:18px;display:flex;align-items:center;justify-content:flex-end;gap:12px;">
            <a href="<?php echo e(route('admin.roles.index')); ?>" style="padding:9px 18px;background:#f1f5f9;color:#64748b;border-radius:8px;font-size:0.85rem;font-weight:600;text-decoration:none;">Cancel</a>
            <button type="submit" style="padding:9px 22px;background:var(--admin-primary);color:#fff;border:none;border-radius:8px;font-size:0.85rem;font-weight:700;cursor:pointer;">Save Role</button>
        </div>
    </form>
</div>

<script>
    function toggleAllPermissions(master) {
        document.querySelectorAll('.perm-checkbox').forEach(cb => cb.checked = master.checked);
        document.querySelectorAll('.module-select-all').forEach(cb => cb.checked = master.checked);
    }

    function toggleModulePermissions(moduleMaster, moduleSlug) {
        document.querySelectorAll('.perm-module-' + moduleSlug).forEach(cb => cb.checked = moduleMaster.checked);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Italian Pizza\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>