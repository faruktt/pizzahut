<?php $__env->startSection('title', 'Manage Orders | Italian Pizza Admin'); ?>
<?php $__env->startSection('page-title', 'Orders Management'); ?>

<?php $__env->startSection('admin-content'); ?>
<div class="card-panel">
    <!-- Header with Filters & Create Button -->
    <div class="card-panel-header" style="flex-wrap: wrap; gap: 16px;">
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn-view-store <?php echo e(!request('type') ? 'active' : ''); ?>" style="<?php echo e(!request('type') ? 'background: #0284c7; color: #fff;' : ''); ?>">
                All Orders
            </a>
            <a href="<?php echo e(route('admin.orders.index')); ?>?type=delivery" class="btn-view-store" style="<?php echo e(request('type') == 'delivery' ? 'background: #0284c7; color: #fff;' : ''); ?>">
                <i class="fa-solid fa-motorcycle"></i> Delivery
            </a>
            <a href="<?php echo e(route('admin.orders.index')); ?>?type=takeaway" class="btn-view-store" style="<?php echo e(request('type') == 'takeaway' ? 'background: #0284c7; color: #fff;' : ''); ?>">
                <i class="fa-solid fa-bag-shopping"></i> Takeaway
            </a>
            <a href="<?php echo e(route('admin.orders.index')); ?>?type=dine_in" class="btn-view-store" style="<?php echo e(request('type') == 'dine_in' ? 'background: #0284c7; color: #fff;' : ''); ?>">
                <i class="fa-solid fa-utensils"></i> Dine-in (Tables)
            </a>
        </div>

        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
            <form action="<?php echo e(route('admin.orders.index')); ?>" method="GET" style="display: flex; gap: 6px; align-items: center;">
                <?php if(request('type')): ?>
                    <input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
                <?php endif; ?>
                <select name="status" onchange="this.form.submit()" class="form-control" style="padding: 6px 10px; font-size: 0.85rem; border: 1px solid var(--border-light); border-radius: 6px; width: auto;">
                    <option value="">All Statuses</option>
                    <?php $__currentLoopData = $orderStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($st->slug); ?>" <?php echo e(request('status') == $st->slug ? 'selected' : ''); ?>>
                            <?php echo e($st->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Order #, name, phone..." class="form-control" style="padding: 6px 12px; font-size: 0.85rem; border: 1px solid var(--border-light); border-radius: 6px;">
                <button type="submit" class="btn-view-store">Search</button>
            </form>

            <a href="<?php echo e(route('admin.order-statuses.index')); ?>" class="btn-view-store" title="Manage dynamic order statuses">
                <i class="fa-solid fa-tags"></i> Statuses
            </a>

            <a href="<?php echo e(route('admin.orders.create')); ?>" class="btn-quick-pos">
                <i class="fa-solid fa-plus"></i> Walk-in Order
            </a>
        </div>
    </div>

    <!-- Orders Table -->
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Order #</th>
                    <th>Date / Time</th>
                    <th>Type</th>
                    <th>Customer / Table</th>
                    <th>Items</th>
                    <th>Total (৳)</th>
                    <th>Payment</th>
                    <th>Order Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <strong>#<?php echo e($ord->order_number); ?></strong>
                        </td>
                        <td>
                            <div style="font-size: 0.8rem; color: #475569;"><?php echo e($ord->created_at->format('d M Y, h:i A')); ?></div>
                        </td>
                        <td>
                            <span style="font-weight: 700; font-size: 0.78rem; text-transform: uppercase;">
                                <?php if($ord->order_type === 'delivery'): ?>
                                    <i class="fa-solid fa-motorcycle"></i> Delivery
                                <?php elseif($ord->order_type === 'takeaway'): ?>
                                    <i class="fa-solid fa-bag-shopping"></i> Takeaway
                                <?php else: ?>
                                    <i class="fa-solid fa-utensils"></i> Dine-in
                                <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <?php if($ord->order_type === 'dine_in' && $ord->table): ?>
                                <strong><?php echo e($ord->table->table_number); ?></strong>
                            <?php else: ?>
                                <strong><?php echo e($ord->customer_name ?: 'Guest'); ?></strong>
                                <div style="font-size: 0.75rem; color: #64748b;"><?php echo e($ord->customer_phone); ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div style="font-size: 0.82rem;"><?php echo e($ord->items->count()); ?> item(s)</div>
                        </td>
                        <td>
                            <strong style="color: var(--admin-primary); font-size: 0.95rem;">
                                ৳ <?php echo e(number_format($ord->total_amount)); ?>

                            </strong>
                            <?php if($ord->due_amount > 0): ?>
                                <div style="color:#dc2626; font-size:0.75rem; font-weight:700;">Due: ৳<?php echo e(number_format($ord->due_amount)); ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($ord->payment_status === 'paid'): ?>
                                <span class="badge" style="background:#dcfce7; color:#15803d;">Paid</span>
                            <?php elseif($ord->payment_status === 'partial'): ?>
                                <span class="badge" style="background:#fef3c7; color:#b45309;">Partial</span>
                            <?php else: ?>
                                <span class="badge" style="background:#fee2e2; color:#b91c1c;">Due</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                                $curStatusObj = $orderStatuses->firstWhere('slug', $ord->order_status)
                                    ?? \App\Models\OrderStatus::findBySlugOrName($ord->order_status);
                                $stBgColor = $curStatusObj->bg_color ?? '#f1f5f9';
                                $stColor = $curStatusObj->color ?? '#334155';
                            ?>
                            <form action="<?php echo e(route('admin.orders.updateStatus', $ord->id)); ?>" method="POST" style="display:inline-block; margin:0;">
                                <?php echo csrf_field(); ?>
                                <div style="position:relative; display:inline-block;">
                                    <select name="order_status" onchange="this.form.submit()" style="padding: 5px 24px 5px 12px; border-radius: 999px; font-size: 0.78rem; font-weight: 700; border: 1.5px solid <?php echo e($stColor); ?>40; background-color: <?php echo e($stBgColor); ?>; color: <?php echo e($stColor); ?>; cursor: pointer; outline: none; appearance: none; -webkit-appearance: none; box-shadow: 0 1px 3px rgba(0,0,0,0.06); transition: all 0.2s;">
                                        <?php $__currentLoopData = $orderStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statusItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($statusItem->slug); ?>" <?php echo e($ord->order_status === $statusItem->slug ? 'selected' : ''); ?> style="background:#fff; color:#0f172a; font-weight:600;">
                                                ● <?php echo e($statusItem->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!$orderStatuses->contains('slug', $ord->order_status) && $ord->order_status): ?>
                                            <option value="<?php echo e($ord->order_status); ?>" selected style="background:#fff; color:#0f172a; font-weight:600;">
                                                ● <?php echo e(ucfirst(str_replace('_', ' ', $ord->order_status))); ?>

                                            </option>
                                        <?php endif; ?>
                                    </select>
                                    <i class="fa-solid fa-chevron-down" style="position:absolute; right:9px; top:50%; transform:translateY(-50%); font-size:0.65rem; color:<?php echo e($stColor); ?>; pointer-events:none;"></i>
                                </div>
                            </form>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.orders.show', $ord->id)); ?>" class="btn-view-store" style="padding: 4px 10px; font-size: 0.75rem;">
                                View Details <i class="fa-solid fa-angle-right"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 40px; color: #94a3b8;">
                            No orders found.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="padding: 16px 24px;">
        <?php echo e($orders->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Italian Pizza\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>