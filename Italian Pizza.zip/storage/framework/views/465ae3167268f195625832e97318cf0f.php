<?php $__env->startSection('title', 'Edit Product | Italian Pizza Admin'); ?>
<?php $__env->startSection('page-title', 'Edit Product'); ?>

<?php $__env->startSection('admin-content'); ?>
<div style="max-width:960px;">
    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary" style="margin-bottom:20px;">
        <i class="fa-solid fa-arrow-left"></i> Back
    </a>

    <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="card-panel" style="margin-bottom:20px;">
            <div class="card-panel-header">
                <span class="card-panel-title"><i class="fa-solid fa-circle-info"></i> Basic Information</span>
            </div>
            <div class="card-panel-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Product Name *</label>
                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $product->name)); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Category *</label>
                        <select name="category_id" class="form-control" required>
                            <option value="">— Select Category —</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>" <?php echo e(old('category_id', $product->category_id) == $cat->id ? 'selected' : ''); ?>>
                                    <?php echo e($cat->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="form-error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Base Price (৳) *</label>
                        <input type="number" name="base_price" step="0.01" min="0" class="form-control" value="<?php echo e(old('base_price', $product->base_price)); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fa-solid fa-coins" style="color:#f59e0b;"></i> Reward Points Earned</label>
                        <input type="number" name="reward_points" min="0" class="form-control" value="<?php echo e(old('reward_points', $product->reward_points ?? 0)); ?>" placeholder="e.g. 15">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Product Image</label>
                        <?php if($product->image): ?>
                        <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px;">
                            <img src="<?php echo e(asset('uploads/' . $product->image)); ?>" style="height:60px;width:60px;object-fit:cover;border-radius:6px;border:1px solid #e2e8f0;">
                            <span style="font-size:0.78rem;color:#64748b;">Current image: <?php echo e($product->image); ?></span>
                        </div>
                        <?php endif; ?>
                        <input type="file" name="image" class="form-control" accept="image/*" onchange="previewMainImg(this)">
                        <img id="mainImgPreview" src="" style="display:none;margin-top:8px;height:70px;border-radius:6px;object-fit:cover;">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="2"><?php echo e(old('description', $product->description)); ?></textarea>
                </div>

                <div style="display:flex;gap:20px;flex-wrap:wrap;padding-top:4px;">
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:0.85rem;font-weight:600;">
                        <input type="checkbox" name="is_bestseller" <?php echo e(old('is_bestseller', $product->is_bestseller) ? 'checked' : ''); ?>> <i class="fa-solid fa-fire" style="color:#f59e0b;"></i> Bestseller
                    </label>
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:0.85rem;font-weight:600;">
                        <input type="checkbox" name="is_new" <?php echo e(old('is_new', $product->is_new) ? 'checked' : ''); ?>> <i class="fa-solid fa-star" style="color:#3b82f6;"></i> New Item
                    </label>
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:0.85rem;font-weight:600;">
                        <input type="checkbox" name="is_active" <?php echo e(old('is_active', $product->is_active) ? 'checked' : ''); ?>> <i class="fa-solid fa-check" style="color:#10b981;"></i> Active
                    </label>
                </div>
            </div>
        </div>

        
        <div class="card-panel" style="margin-bottom:20px;">
            <div class="card-panel-header" style="justify-content:space-between;">
                <div>
                    <span class="card-panel-title"><i class="fa-solid fa-layer-group"></i> Variations (Sizes & Crusts)</span>
                </div>
                <div style="display:flex;gap:8px;">
                    <a href="<?php echo e(route('admin.sizes.index')); ?>" target="_blank" class="btn btn-secondary btn-sm">
                        <i class="fa-solid fa-ruler-horizontal"></i> Sizes
                    </a>
                    <a href="<?php echo e(route('admin.crusts.index')); ?>" target="_blank" class="btn btn-secondary btn-sm">
                        <i class="fa-solid fa-circle-half-stroke"></i> Crusts
                    </a>
                </div>
            </div>

            <div class="card-panel-body">
                
                <div style="margin-bottom:20px;">
                    <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:10px;display:block;">
                        Step 1: Choose Available Sizes
                    </label>

                    <?php if($sizes->isNotEmpty()): ?>
                    <div style="display:flex;flex-wrap:wrap;gap:12px;">
                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isSizeActive = in_array($size->id, $selectedSizeIds);
                        ?>
                        <label style="display:flex;align-items:center;gap:8px;padding:10px 16px;border:2px solid <?php echo e($isSizeActive ? 'var(--admin-primary)' : '#e2e8f0'); ?>;border-radius:10px;cursor:pointer;background:<?php echo e($isSizeActive ? '#fef2f2' : '#fff'); ?>;transition:all 0.2s;font-size:0.9rem;font-weight:700;" class="size-pill" id="pill_size_<?php echo e($size->id); ?>">
                            <input type="checkbox" name="size_selected_<?php echo e($size->id); ?>" id="chk_size_<?php echo e($size->id); ?>" value="1" onchange="toggleSizeBox(<?php echo e($size->id); ?>)" <?php echo e($isSizeActive ? 'checked' : ''); ?> style="width:18px;height:18px;accent-color:var(--admin-primary);">
                            <span><?php echo e($size->name); ?></span>
                        </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>

                
                <div id="variationsBoxesWrap">
                    <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:10px;display:block;">
                        Step 2: Configure Crust, Price & Image for Selected Sizes
                    </label>

                    <div id="noSizeSelectedMsg" style="display:<?php echo e(count($selectedSizeIds) > 0 ? 'none' : 'block'); ?>;padding:24px;text-align:center;background:#f8fafc;border:2px dashed #cbd5e1;border-radius:12px;color:#64748b;font-size:0.88rem;">
                        <i class="fa-solid fa-hand-pointer" style="font-size:1.5rem;display:block;margin-bottom:8px;color:#94a3b8;"></i>
                        Please select one or more sizes above to configure crust variations, prices, and images.
                    </div>

                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isSizeActive = in_array($size->id, $selectedSizeIds);
                        $existingSizePrice = $existingSizes[$size->id] ?? ($product->allVariations->where('size_id', $size->id)->first()->price ?? '');
                    ?>
                    <div class="size-variation-card" id="sizeCard_<?php echo e($size->id); ?>" style="display:<?php echo e($isSizeActive ? 'block' : 'none'); ?>;background:#fcfcfd;border:1px solid #e2e8f0;border-radius:12px;padding:18px;margin-bottom:18px;box-shadow:0 1px 3px rgba(0,0,0,0.02);">
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid #e2e8f0;flex-wrap:wrap;gap:12px;">
                            <div style="display:flex;align-items:center;gap:8px;">
                                <span style="background:var(--admin-primary);color:#fff;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.75rem;">
                                    <i class="fa-solid fa-ruler"></i>
                                </span>
                                <h4 style="margin:0;font-size:1rem;font-weight:800;color:#1e293b;">
                                    Size: <?php echo e($size->name); ?>

                                </h4>
                            </div>

                            <div style="display:flex;align-items:center;gap:8px;">
                                <label style="font-size:0.85rem;font-weight:700;color:#334155;margin:0;">
                                    Size Price (৳):
                                </label>
                                <input type="number" 
                                       step="0.01" 
                                       min="0" 
                                       name="size_prices[<?php echo e($size->id); ?>]" 
                                       id="size_price_<?php echo e($size->id); ?>" 
                                       value="<?php echo e($existingSizePrice); ?>"
                                       placeholder="e.g. 450" 
                                       class="form-control" 
                                       style="width:140px;padding:6px 10px;font-size:0.9rem;font-weight:700;" 
                                       <?php echo e($isSizeActive ? '' : 'disabled'); ?>>
                            </div>
                        </div>

                        <div style="margin-bottom:10px;display:flex;align-items:center;justify-content:space-between;">
                            <span style="font-size:0.82rem;font-weight:700;color:#64748b;">
                                <i class="fa-solid fa-circle-half-stroke" style="color:var(--admin-primary);margin-right:4px;"></i>
                                Crust Variations (Optional - leave unselected if this size has no crust)
                            </span>
                        </div>

                        <?php if($crusts->isNotEmpty()): ?>
                        <div style="display:flex;flex-direction:column;gap:12px;">
                            <?php $__currentLoopData = $crusts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crust): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $existingVar = $existingVariations[$size->id][$crust->id] ?? null;
                                $isVarActive = !is_null($existingVar);
                                $varPrice = $existingVar ? $existingVar->price : '';
                                $varImage = $existingVar ? $existingVar->image : null;
                            ?>
                            <div class="variation-row" id="varRow_<?php echo e($size->id); ?>_<?php echo e($crust->id); ?>" style="background:<?php echo e($isVarActive ? '#fffafa' : '#fff'); ?>;border:1px solid <?php echo e($isVarActive ? 'var(--admin-primary)' : '#e2e8f0'); ?>;border-radius:10px;padding:12px 16px;display:flex;align-items:center;gap:16px;flex-wrap:wrap;transition:all 0.2s;">
                                
                                <div style="display:flex;align-items:center;gap:10px;min-width:180px;">
                                    <input type="checkbox" 
                                           name="variations[<?php echo e($size->id); ?>][<?php echo e($crust->id); ?>][enabled]" 
                                           id="chk_var_<?php echo e($size->id); ?>_<?php echo e($crust->id); ?>" 
                                           value="1" 
                                           onchange="toggleVarRow(<?php echo e($size->id); ?>, <?php echo e($crust->id); ?>)"
                                           <?php echo e($isVarActive ? 'checked' : ''); ?>

                                           style="width:18px;height:18px;accent-color:var(--admin-primary);">
                                    <label for="chk_var_<?php echo e($size->id); ?>_<?php echo e($crust->id); ?>" style="cursor:pointer;font-weight:700;font-size:0.88rem;color:#1e293b;margin:0;">
                                        <i class="fa-solid fa-circle-half-stroke" style="color:var(--admin-primary);font-size:0.8rem;margin-right:4px;"></i>
                                        <?php echo e($crust->name); ?>

                                    </label>
                                </div>

                                
                                <div style="display:flex;align-items:center;gap:6px;">
                                    <label style="font-size:0.78rem;font-weight:600;color:#64748b;margin:0;">Price (৳):</label>
                                    <input type="number" 
                                           step="0.01" 
                                           min="0" 
                                           name="variations[<?php echo e($size->id); ?>][<?php echo e($crust->id); ?>][price]" 
                                           id="price_var_<?php echo e($size->id); ?>_<?php echo e($crust->id); ?>" 
                                           value="<?php echo e($varPrice); ?>"
                                           placeholder="e.g. 550" 
                                           class="form-control" 
                                           style="width:120px;padding:6px 10px;font-size:0.85rem;" 
                                           <?php echo e($isVarActive ? 'required' : 'disabled'); ?>>
                                </div>

                                
                                <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:240px;">
                                    <?php if($varImage): ?>
                                        <input type="hidden" name="variations[<?php echo e($size->id); ?>][<?php echo e($crust->id); ?>][existing_image]" value="<?php echo e($varImage); ?>">
                                        <img src="<?php echo e(asset('uploads/' . $varImage)); ?>" style="width:40px;height:40px;border-radius:6px;object-fit:cover;border:1px solid #e2e8f0;" title="Current variation image">
                                    <?php endif; ?>
                                    <label style="font-size:0.78rem;font-weight:600;color:#64748b;margin:0;">
                                        <?php echo e($varImage ? 'Change Image:' : 'Image:'); ?>

                                    </label>
                                    <input type="file" 
                                           name="variation_image_<?php echo e($size->id); ?>_<?php echo e($crust->id); ?>" 
                                           id="img_var_<?php echo e($size->id); ?>_<?php echo e($crust->id); ?>" 
                                           accept="image/*" 
                                           class="form-control" 
                                           style="padding:4px 8px;font-size:0.78rem;" 
                                           onchange="previewVarImg(this, 'preview_<?php echo e($size->id); ?>_<?php echo e($crust->id); ?>')" 
                                           <?php echo e($isVarActive ? '' : 'disabled'); ?>>
                                    <img id="preview_<?php echo e($size->id); ?>_<?php echo e($crust->id); ?>" 
                                         src="" 
                                         style="display:none;width:40px;height:40px;border-radius:6px;object-fit:cover;border:1px solid #e2e8f0;">
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary" style="padding:12px 28px;font-size:0.95rem;">
            <i class="fa-solid fa-save"></i> Update Product & Variations
        </button>
    </form>
</div>

<?php $__env->startPush('admin-scripts'); ?>
<script>
    function previewMainImg(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = e => {
                const img = document.getElementById('mainImgPreview');
                img.src = e.target.result;
                img.style.display = 'block';
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    function previewVarImg(input, previewId) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = e => {
                const img = document.getElementById(previewId);
                img.src = e.target.result;
                img.style.display = 'block';
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    function toggleSizeBox(sizeId) {
        const chk = document.getElementById('chk_size_' + sizeId);
        const card = document.getElementById('sizeCard_' + sizeId);
        const pill = document.getElementById('pill_size_' + sizeId);
        const sizePriceInput = document.getElementById('size_price_' + sizeId);

        if (chk.checked) {
            card.style.display = 'block';
            pill.style.borderColor = 'var(--admin-primary)';
            pill.style.background = '#fef2f2';
            if (sizePriceInput) {
                sizePriceInput.disabled = false;
            }
        } else {
            card.style.display = 'none';
            pill.style.borderColor = '#e2e8f0';
            pill.style.background = '#fff';
            if (sizePriceInput) {
                sizePriceInput.disabled = true;
            }
            // Disable all crusts in this size
            const crustCheckboxes = card.querySelectorAll('input[type="checkbox"]');
            crustCheckboxes.forEach(c => {
                c.checked = false;
                const match = c.id.match(/chk_var_(\d+)_(\d+)/);
                if (match) {
                    toggleVarRow(match[1], match[2]);
                }
            });
        }
        checkAnySizeActive();
    }

    function toggleVarRow(sizeId, crustId) {
        const chk = document.getElementById('chk_var_' + sizeId + '_' + crustId);
        const priceInput = document.getElementById('price_var_' + sizeId + '_' + crustId);
        const imgInput = document.getElementById('img_var_' + sizeId + '_' + crustId);
        const row = document.getElementById('varRow_' + sizeId + '_' + crustId);

        if (chk.checked) {
            priceInput.disabled = false;
            priceInput.required = true;
            imgInput.disabled = false;
            row.style.borderColor = 'var(--admin-primary)';
            row.style.background = '#fffafa';
        } else {
            priceInput.disabled = true;
            priceInput.required = false;
            imgInput.disabled = true;
            row.style.borderColor = '#e2e8f0';
            row.style.background = '#fff';
        }
    }

    function checkAnySizeActive() {
        const anyChecked = document.querySelectorAll('input[id^="chk_size_"]:checked').length > 0;
        const msg = document.getElementById('noSizeSelectedMsg');
        if (msg) {
            msg.style.display = anyChecked ? 'none' : 'block';
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Italian Pizza\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>