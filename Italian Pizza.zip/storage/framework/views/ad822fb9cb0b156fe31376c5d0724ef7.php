<?php $__env->startSection('title', 'Products | Italian Pizza Admin'); ?>
<?php $__env->startSection('page-title', 'Products & Menu'); ?>

<?php $__env->startSection('admin-content'); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
    <form method="GET" style="display:flex;gap:10px;">
        <input type="text" name="search" class="form-control" placeholder="Search product..." value="<?php echo e(request('search')); ?>" style="width:220px;">
        <select name="category_id" class="form-control" style="width:180px;">
            <option value="">All Categories</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit" class="btn btn-secondary"><i class="fa-solid fa-magnifying-glass"></i></button>
        <?php if(request()->hasAny(['search','category_id'])): ?>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary"><i class="fa-solid fa-xmark"></i></a>
        <?php endif; ?>
    </form>
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary">
        <i class="fa-solid fa-plus"></i> Add Product
    </a>
</div>

<div class="card-panel">
    <table class="admin-table">
        <thead>
            <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Sizes</th>
                <th>Crusts</th>
                <th>Tags</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php if($product->image): ?>
                        <img src="<?php echo e(asset('uploads/' . $product->image)); ?>" style="width:44px;height:44px;object-fit:cover;border-radius:8px;">
                    <?php else: ?>
                        <div style="width:44px;height:44px;background:#f1f5f9;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#94a3b8;">
                            <i class="fa-solid fa-image"></i>
                        </div>
                    <?php endif; ?>
                </td>
                <td><strong><?php echo e($product->name); ?></strong></td>
                <td style="color:#64748b;"><?php echo e($product->category?->name ?? '—'); ?></td>
                <td><strong>৳<?php echo e(number_format($product->base_price, 2)); ?></strong></td>
                <td style="font-size:0.78rem;color:#64748b;">
                    <?php echo e($product->variations->isNotEmpty() ? $product->variations->pluck('size_name')->unique()->filter()->join(', ') : ($product->sizes->pluck('name')->join(', ') ?: '—')); ?>

                </td>
                <td style="font-size:0.78rem;color:#64748b;">
                    <?php echo e($product->variations->isNotEmpty() ? $product->variations->pluck('crust_name')->unique()->filter()->join(', ') : ($product->crusts->pluck('name')->join(', ') ?: '—')); ?>

                </td>
                <td>
                    <?php if($product->is_bestseller): ?><span class="badge" style="background:#fef3c7;color:#b45309;" title="Bestseller"><i class="fa-solid fa-fire"></i></span> <?php endif; ?>
                    <?php if($product->is_new): ?><span class="badge" style="background:#dbeafe;color:#1d4ed8;" title="New"><i class="fa-solid fa-star"></i></span> <?php endif; ?>
                </td>
                <td>
                    <span class="badge <?php echo e($product->is_active ? 'badge-active' : 'badge-inactive'); ?>">
                        <?php echo e($product->is_active ? 'Active' : 'Off'); ?>

                    </span>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-secondary btn-sm">
                        <i class="fa-solid fa-pen"></i>
                    </a>
                    <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Delete this product?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="9" style="text-align:center;color:#94a3b8;padding:40px;">
                <i class="fa-solid fa-box-open" style="font-size:2rem;display:block;margin-bottom:8px;"></i>
                No products yet. <a href="<?php echo e(route('admin.products.create')); ?>">Add first product →</a>
            </td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php if($products->hasPages()): ?>
    <div><?php echo e($products->links()); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Italian Pizza\resources\views/admin/products/index.blade.php ENDPATH**/ ?>