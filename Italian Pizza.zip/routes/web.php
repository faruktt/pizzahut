<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\CustomerAuthController;
use App\Http\Controllers\ComboController;
use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\AdminDashboardController;
use App\Http\Controllers\Admin\AdminOrderController;
use App\Http\Controllers\Admin\AdminProductController;
use App\Http\Controllers\Admin\AdminPosController;
use App\Http\Controllers\Admin\AdminTableController;
use App\Http\Controllers\Admin\AdminCategoryController;
use App\Http\Controllers\Admin\AdminSizeController;
use App\Http\Controllers\Admin\AdminCrustController;
use App\Http\Controllers\Admin\AdminBannerController;
use App\Http\Controllers\Admin\AdminSettingController;
use App\Http\Controllers\Admin\AdminComboController;
use App\Http\Controllers\Admin\AdminAddOnController;
use App\Http\Controllers\Admin\AdminSupplierController;
use App\Http\Controllers\Admin\AdminIngredientController;
use App\Http\Controllers\Admin\AdminPurchaseController;
use App\Http\Controllers\Admin\AdminExpenseController;
use App\Http\Middleware\AdminAuthenticate;
use App\Http\Middleware\AdminRedirectIfAuthenticated;

/*
|--------------------------------------------------------------------------
| Customer & Frontend Routes (Italian Pizza Hut Experience)
|--------------------------------------------------------------------------
*/

// Homepage (Matching Image 1)
Route::get('/', [HomeController::class, 'index'])->name('home');

// Category & Menu Routes
Route::get('/menu', [HomeController::class, 'menu'])->name('menu.index');
Route::get('/category/{slug}', [HomeController::class, 'category'])->name('category.show');

// Product Customization Modal Details (Matching Image 2)
Route::get('/product-details/{id}', [HomeController::class, 'getProductDetails'])->name('product.details');

// Deal Combo Details Page & Ordering
Route::get('/deal/{id}', [\App\Http\Controllers\DealController::class, 'show'])->name('deal.show');
Route::post('/deal/{id}/add', [\App\Http\Controllers\DealController::class, 'addComboToCart'])->name('deal.add');

// Custom CMS Pages
Route::get('/page/{slug}', [HomeController::class, 'showPage'])->name('page.show');

// New Combo Section (admin-managed combos)
Route::get('/combo/{id}', [ComboController::class, 'show'])->name('combo.show');
Route::post('/combo/{id}/add', [ComboController::class, 'addToCart'])->name('combo.add');

// Cart Routes (Matching Image 3)
Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');
Route::post('/cart/update/{key}', [CartController::class, 'update'])->name('cart.update');
Route::post('/cart/remove/{key}', [CartController::class, 'remove'])->name('cart.remove');
Route::post('/cart/apply-coupon', [CartController::class, 'applyCoupon'])->name('cart.applyCoupon');
Route::post('/cart/remove-coupon', [CartController::class, 'removeCoupon'])->name('cart.removeCoupon');
Route::post('/cart/apply-points', [CartController::class, 'applyPoints'])->name('cart.applyPoints');
Route::post('/cart/remove-points', [CartController::class, 'removePoints'])->name('cart.removePoints');

// Checkout & Order Tracking (Protected - Customer must be logged in to order)
Route::middleware('auth:web')->group(function () {
    Route::get('/checkout', [CheckoutController::class, 'index'])->name('checkout.index');
    Route::post('/checkout', [CheckoutController::class, 'store'])->name('checkout.store');
});
Route::get('/order-success/{orderNumber}', [CheckoutController::class, 'success'])->name('checkout.success');

// Customer Authentication (Guard: web)
Route::get('/login', [CustomerAuthController::class, 'showLogin'])->name('login');
Route::post('/login', [CustomerAuthController::class, 'login']);
Route::get('/register', [CustomerAuthController::class, 'showRegister'])->name('register');
Route::post('/register', [CustomerAuthController::class, 'register']);
Route::post('/logout', [CustomerAuthController::class, 'logout'])->name('logout');

// Customer Dashboard (Protected)
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [CustomerAuthController::class, 'dashboard'])->name('customer.dashboard');
    Route::get('/dashboard/orders', [CustomerAuthController::class, 'orders'])->name('customer.orders');
    Route::get('/dashboard/orders/{id}', [CustomerAuthController::class, 'orderDetail'])->name('customer.orders.show');
    Route::put('/dashboard/profile', [CustomerAuthController::class, 'updateProfile'])->name('customer.profile.update');
    Route::put('/dashboard/password', [CustomerAuthController::class, 'updatePassword'])->name('customer.password.update');
});


/*
|--------------------------------------------------------------------------
| Admin Portal & POS System Routes (Guard: admin)
|--------------------------------------------------------------------------
*/

// Admin Guest Routes
Route::prefix('admin')->group(function () {
    Route::get('/login', [AdminAuthController::class, 'showLogin'])
        ->middleware(AdminRedirectIfAuthenticated::class)
        ->name('admin.login');
    Route::post('/login', [AdminAuthController::class, 'login'])
        ->middleware(AdminRedirectIfAuthenticated::class);
});

// Admin Protected Routes (Light Dashboard, POS, Product & Order Management)
Route::prefix('admin')->middleware(AdminAuthenticate::class)->group(function () {
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('admin.logout');
    
    // Dashboard (Premium Light Theme)
    Route::get('/', [AdminDashboardController::class, 'index'])->name('admin.dashboard');
    Route::get('/dashboard', [AdminDashboardController::class, 'index']);

    // Point of Sale (POS) - Table & Live Dine-in Ordering
    Route::get('/pos', [AdminPosController::class, 'index'])->name('admin.pos.index');
    Route::get('/pos/customers/search', [AdminPosController::class, 'searchCustomers'])->name('admin.pos.customers.search');
    Route::post('/pos/customers/quick-add', [AdminPosController::class, 'quickAddCustomer'])->name('admin.pos.customers.quickAdd');
    Route::get('/pos/table/{tableId}', [AdminPosController::class, 'getTableOrder'])->name('admin.pos.tableOrder');
    Route::post('/pos/table/{tableId}/add', [AdminPosController::class, 'addItemToTable'])->name('admin.pos.addItem');
    Route::post('/pos/table/{tableId}/customer', [AdminPosController::class, 'updateTableCustomer'])->name('admin.pos.updateCustomer');
    Route::post('/pos/item/{itemId}/remove', [AdminPosController::class, 'removeItemFromTable'])->name('admin.pos.removeItem');
    Route::post('/pos/item/{itemId}/update-qty', [AdminPosController::class, 'updateItemQuantity'])->name('admin.pos.updateQty');
    Route::post('/pos/table/{tableId}/complete', [AdminPosController::class, 'completeTableOrder'])->name('admin.pos.completeOrder');

    // Orders Management (Supports orders with or without registered customers)
    Route::get('/orders', [AdminOrderController::class, 'index'])->name('admin.orders.index');
    Route::get('/orders/create', [AdminOrderController::class, 'create'])->name('admin.orders.create');
    Route::post('/orders', [AdminOrderController::class, 'store'])->name('admin.orders.store');
    Route::get('/orders/{id}', [AdminOrderController::class, 'show'])->name('admin.orders.show');
    Route::post('/orders/{id}/status', [AdminOrderController::class, 'updateStatus'])->name('admin.orders.updateStatus');

    // Dynamic Order Statuses CRUD
    Route::get('/order-statuses', [\App\Http\Controllers\Admin\AdminOrderStatusController::class, 'index'])->name('admin.order-statuses.index');
    Route::get('/order-statuses/create', [\App\Http\Controllers\Admin\AdminOrderStatusController::class, 'create'])->name('admin.order-statuses.create');
    Route::post('/order-statuses', [\App\Http\Controllers\Admin\AdminOrderStatusController::class, 'store'])->name('admin.order-statuses.store');
    Route::get('/order-statuses/{id}/edit', [\App\Http\Controllers\Admin\AdminOrderStatusController::class, 'edit'])->name('admin.order-statuses.edit');
    Route::put('/order-statuses/{id}', [\App\Http\Controllers\Admin\AdminOrderStatusController::class, 'update'])->name('admin.order-statuses.update');
    Route::delete('/order-statuses/{id}', [\App\Http\Controllers\Admin\AdminOrderStatusController::class, 'destroy'])->name('admin.order-statuses.destroy');
    Route::post('/order-statuses/{id}/toggle', [\App\Http\Controllers\Admin\AdminOrderStatusController::class, 'toggleStatus'])->name('admin.order-statuses.toggle');

    // Products Management (Sizes, Crusts, Prices)
    Route::get('/products', [AdminProductController::class, 'index'])->name('admin.products.index');
    Route::get('/products/create', [AdminProductController::class, 'create'])->name('admin.products.create');
    Route::post('/products', [AdminProductController::class, 'store'])->name('admin.products.store');
    Route::get('/products/{id}/edit', [AdminProductController::class, 'edit'])->name('admin.products.edit');
    Route::put('/products/{id}', [AdminProductController::class, 'update'])->name('admin.products.update');
    Route::delete('/products/{id}', [AdminProductController::class, 'destroy'])->name('admin.products.destroy');

    // Restaurant Tables Management
    Route::get('/tables', [AdminTableController::class, 'index'])->name('admin.tables.index');
    Route::post('/tables', [AdminTableController::class, 'store'])->name('admin.tables.store');
    Route::post('/tables/{id}/status', [AdminTableController::class, 'updateStatus'])->name('admin.tables.updateStatus');
    Route::delete('/tables/{id}', [AdminTableController::class, 'destroy'])->name('admin.tables.destroy');

    // Categories CRUD
    Route::get('/categories', [AdminCategoryController::class, 'index'])->name('admin.categories.index');
    Route::get('/categories/create', [AdminCategoryController::class, 'create'])->name('admin.categories.create');
    Route::post('/categories', [AdminCategoryController::class, 'store'])->name('admin.categories.store');
    Route::get('/categories/{id}/edit', [AdminCategoryController::class, 'edit'])->name('admin.categories.edit');
    Route::put('/categories/{id}', [AdminCategoryController::class, 'update'])->name('admin.categories.update');
    Route::delete('/categories/{id}', [AdminCategoryController::class, 'destroy'])->name('admin.categories.destroy');

    // Sizes CRUD
    Route::get('/sizes', [AdminSizeController::class, 'index'])->name('admin.sizes.index');
    Route::post('/sizes', [AdminSizeController::class, 'store'])->name('admin.sizes.store');
    Route::put('/sizes/{id}', [AdminSizeController::class, 'update'])->name('admin.sizes.update');
    Route::delete('/sizes/{id}', [AdminSizeController::class, 'destroy'])->name('admin.sizes.destroy');

    // Crusts CRUD
    Route::get('/crusts', [AdminCrustController::class, 'index'])->name('admin.crusts.index');
    Route::post('/crusts', [AdminCrustController::class, 'store'])->name('admin.crusts.store');
    Route::put('/crusts/{id}', [AdminCrustController::class, 'update'])->name('admin.crusts.update');
    Route::delete('/crusts/{id}', [AdminCrustController::class, 'destroy'])->name('admin.crusts.destroy');

    // Add Ons CRUD (Extra items for products)
    Route::get('/addons', [AdminAddOnController::class, 'index'])->name('admin.addons.index');
    Route::get('/addons/create', [AdminAddOnController::class, 'create'])->name('admin.addons.create');
    Route::post('/addons', [AdminAddOnController::class, 'store'])->name('admin.addons.store');
    Route::get('/addons/{id}/edit', [AdminAddOnController::class, 'edit'])->name('admin.addons.edit');
    Route::put('/addons/{id}', [AdminAddOnController::class, 'update'])->name('admin.addons.update');
    Route::delete('/addons/{id}', [AdminAddOnController::class, 'destroy'])->name('admin.addons.destroy');
    Route::post('/addons/{id}/toggle', [AdminAddOnController::class, 'toggleStatus'])->name('admin.addons.toggle');

    // Combos CRUD (admin-managed combo meals)
    Route::get('/combos', [AdminComboController::class, 'index'])->name('admin.combos.index');
    Route::get('/combos/create', [AdminComboController::class, 'create'])->name('admin.combos.create');
    Route::post('/combos', [AdminComboController::class, 'store'])->name('admin.combos.store');
    Route::get('/combos/{id}/edit', [AdminComboController::class, 'edit'])->name('admin.combos.edit');
    Route::put('/combos/{id}', [AdminComboController::class, 'update'])->name('admin.combos.update');
    Route::delete('/combos/{id}', [AdminComboController::class, 'destroy'])->name('admin.combos.destroy');
    Route::post('/combos/{id}/toggle', [AdminComboController::class, 'toggleStatus'])->name('admin.combos.toggle');

    // Coupons CRUD
    Route::get('/coupons', [\App\Http\Controllers\Admin\AdminCouponController::class, 'index'])->name('admin.coupons.index');
    Route::get('/coupons/create', [\App\Http\Controllers\Admin\AdminCouponController::class, 'create'])->name('admin.coupons.create');
    Route::post('/coupons', [\App\Http\Controllers\Admin\AdminCouponController::class, 'store'])->name('admin.coupons.store');
    Route::get('/coupons/{id}/edit', [\App\Http\Controllers\Admin\AdminCouponController::class, 'edit'])->name('admin.coupons.edit');
    Route::put('/coupons/{id}', [\App\Http\Controllers\Admin\AdminCouponController::class, 'update'])->name('admin.coupons.update');
    Route::delete('/coupons/{id}', [\App\Http\Controllers\Admin\AdminCouponController::class, 'destroy'])->name('admin.coupons.destroy');
    Route::post('/coupons/{id}/toggle', [\App\Http\Controllers\Admin\AdminCouponController::class, 'toggleStatus'])->name('admin.coupons.toggleStatus');

    // Website Banners CRUD (multiple banners shown on frontend)
    Route::get('/banners', [AdminBannerController::class, 'index'])->name('admin.banners.index');
    Route::get('/banners/create', [AdminBannerController::class, 'create'])->name('admin.banners.create');
    Route::post('/banners', [AdminBannerController::class, 'store'])->name('admin.banners.store');
    Route::get('/banners/{id}/edit', [AdminBannerController::class, 'edit'])->name('admin.banners.edit');
    Route::put('/banners/{id}', [AdminBannerController::class, 'update'])->name('admin.banners.update');
    Route::delete('/banners/{id}', [AdminBannerController::class, 'destroy'])->name('admin.banners.destroy');

    // Website Settings (Logo & Favicon management)
    Route::get('/settings', [AdminSettingController::class, 'index'])->name('admin.settings.index');
    Route::post('/settings/general', [AdminSettingController::class, 'updateGeneral'])->name('admin.settings.general');
    Route::post('/settings/logo', [AdminSettingController::class, 'updateLogo'])->name('admin.settings.logo');
    Route::post('/settings/favicon', [AdminSettingController::class, 'updateFavicon'])->name('admin.settings.favicon');
    Route::delete('/settings/logo', [AdminSettingController::class, 'removeLogo'])->name('admin.settings.logo.remove');
    Route::delete('/settings/favicon', [AdminSettingController::class, 'removeFavicon'])->name('admin.settings.favicon.remove');
    Route::get('/settings/points', [AdminSettingController::class, 'pointsIndex'])->name('admin.settings.points');
    Route::post('/settings/points', [AdminSettingController::class, 'updatePoints'])->name('admin.settings.points.update');
    Route::get('/settings/shipping', [AdminSettingController::class, 'shippingIndex'])->name('admin.settings.shipping');
    Route::post('/settings/shipping', [AdminSettingController::class, 'updateShipping'])->name('admin.settings.shipping.update');

    // Website CMS Pages CRUD
    Route::get('/pages', [\App\Http\Controllers\Admin\AdminPageController::class, 'index'])->name('admin.pages.index');
    Route::get('/pages/create', [\App\Http\Controllers\Admin\AdminPageController::class, 'create'])->name('admin.pages.create');
    Route::post('/pages', [\App\Http\Controllers\Admin\AdminPageController::class, 'store'])->name('admin.pages.store');
    Route::get('/pages/{id}/edit', [\App\Http\Controllers\Admin\AdminPageController::class, 'edit'])->name('admin.pages.edit');
    Route::put('/pages/{id}', [\App\Http\Controllers\Admin\AdminPageController::class, 'update'])->name('admin.pages.update');
    Route::delete('/pages/{id}', [\App\Http\Controllers\Admin\AdminPageController::class, 'destroy'])->name('admin.pages.destroy');
    Route::post('/pages/{id}/toggle', [\App\Http\Controllers\Admin\AdminPageController::class, 'toggleStatus'])->name('admin.pages.toggleStatus');

    // Admin Profile & Password Management
    Route::get('/profile', [\App\Http\Controllers\Admin\AdminProfileController::class, 'edit'])->name('admin.profile');
    Route::put('/profile', [\App\Http\Controllers\Admin\AdminProfileController::class, 'updateProfile'])->name('admin.profile.update');
    Route::put('/profile/password', [\App\Http\Controllers\Admin\AdminProfileController::class, 'updatePassword'])->name('admin.profile.password');

    // Customer / User Management & Account Blocking
    Route::middleware('admin.permission:users.view')->group(function () {
        Route::get('/users', [\App\Http\Controllers\Admin\AdminUserController::class, 'index'])->name('admin.users.index');
        Route::get('/users/{id}', [\App\Http\Controllers\Admin\AdminUserController::class, 'show'])->name('admin.users.show');
    });
    Route::post('/users/{id}/toggle-block', [\App\Http\Controllers\Admin\AdminUserController::class, 'toggleBlock'])
        ->middleware('admin.permission:users.block')
        ->name('admin.users.toggleBlock');
    Route::delete('/users/{id}', [\App\Http\Controllers\Admin\AdminUserController::class, 'destroy'])
        ->middleware('admin.permission:users.delete')
        ->name('admin.users.destroy');

    // Role & Permission Management
    Route::middleware('admin.permission:roles.manage')->group(function () {
        Route::get('/roles', [\App\Http\Controllers\Admin\AdminRoleController::class, 'index'])->name('admin.roles.index');
        Route::get('/roles/create', [\App\Http\Controllers\Admin\AdminRoleController::class, 'create'])->name('admin.roles.create');
        Route::post('/roles', [\App\Http\Controllers\Admin\AdminRoleController::class, 'store'])->name('admin.roles.store');
        Route::get('/roles/{id}/edit', [\App\Http\Controllers\Admin\AdminRoleController::class, 'edit'])->name('admin.roles.edit');
        Route::put('/roles/{id}', [\App\Http\Controllers\Admin\AdminRoleController::class, 'update'])->name('admin.roles.update');
        Route::delete('/roles/{id}', [\App\Http\Controllers\Admin\AdminRoleController::class, 'destroy'])->name('admin.roles.destroy');
    });

    // Staff / Sub-Admin Management
    Route::middleware('admin.permission:admins.manage')->group(function () {
        Route::get('/staff', [\App\Http\Controllers\Admin\AdminStaffController::class, 'index'])->name('admin.staff.index');
        Route::get('/staff/create', [\App\Http\Controllers\Admin\AdminStaffController::class, 'create'])->name('admin.staff.create');
        Route::post('/staff', [\App\Http\Controllers\Admin\AdminStaffController::class, 'store'])->name('admin.staff.store');
        Route::get('/staff/{id}/edit', [\App\Http\Controllers\Admin\AdminStaffController::class, 'edit'])->name('admin.staff.edit');
        Route::put('/staff/{id}', [\App\Http\Controllers\Admin\AdminStaffController::class, 'update'])->name('admin.staff.update');
        Route::delete('/staff/{id}', [\App\Http\Controllers\Admin\AdminStaffController::class, 'destroy'])->name('admin.staff.destroy');
    });

    // Inventory: Suppliers
    Route::get('/suppliers', [AdminSupplierController::class, 'index'])->name('admin.suppliers.index');
    Route::get('/suppliers/create', [AdminSupplierController::class, 'create'])->name('admin.suppliers.create');
    Route::post('/suppliers', [AdminSupplierController::class, 'store'])->name('admin.suppliers.store');
    Route::get('/suppliers/{id}/edit', [AdminSupplierController::class, 'edit'])->name('admin.suppliers.edit');
    Route::put('/suppliers/{id}', [AdminSupplierController::class, 'update'])->name('admin.suppliers.update');
    Route::delete('/suppliers/{id}', [AdminSupplierController::class, 'destroy'])->name('admin.suppliers.destroy');

    // Inventory: Ingredients
    Route::get('/ingredients', [AdminIngredientController::class, 'index'])->name('admin.ingredients.index');
    Route::get('/ingredients/create', [AdminIngredientController::class, 'create'])->name('admin.ingredients.create');
    Route::post('/ingredients', [AdminIngredientController::class, 'store'])->name('admin.ingredients.store');
    Route::get('/ingredients/{id}/edit', [AdminIngredientController::class, 'edit'])->name('admin.ingredients.edit');
    Route::put('/ingredients/{id}', [AdminIngredientController::class, 'update'])->name('admin.ingredients.update');
    Route::delete('/ingredients/{id}', [AdminIngredientController::class, 'destroy'])->name('admin.ingredients.destroy');
    Route::post('/ingredients/{id}/adjust-stock', [AdminIngredientController::class, 'adjustStock'])->name('admin.ingredients.adjustStock');

    // Inventory: Purchases
    Route::get('/purchases', [AdminPurchaseController::class, 'index'])->name('admin.purchases.index');
    Route::get('/purchases/create', [AdminPurchaseController::class, 'create'])->name('admin.purchases.create');
    Route::post('/purchases', [AdminPurchaseController::class, 'store'])->name('admin.purchases.store');
    Route::get('/purchases/{id}', [AdminPurchaseController::class, 'show'])->name('admin.purchases.show');
    Route::delete('/purchases/{id}', [AdminPurchaseController::class, 'destroy'])->name('admin.purchases.destroy');

    // Inventory: Expenses
    Route::get('/expenses', [AdminExpenseController::class, 'index'])->name('admin.expenses.index');
    Route::get('/expenses/create', [AdminExpenseController::class, 'create'])->name('admin.expenses.create');
    Route::post('/expenses', [AdminExpenseController::class, 'store'])->name('admin.expenses.store');
    Route::get('/expenses/{id}/edit', [AdminExpenseController::class, 'edit'])->name('admin.expenses.edit');
    Route::put('/expenses/{id}', [AdminExpenseController::class, 'update'])->name('admin.expenses.update');
    Route::delete('/expenses/{id}', [AdminExpenseController::class, 'destroy'])->name('admin.expenses.destroy');

    // Due Customers Management (বাকি খাতা)
    Route::get('/due-customers', [\App\Http\Controllers\Admin\AdminDueCustomerController::class, 'index'])->name('admin.due-customers.index');
    Route::get('/due-customers/{customerKey}', [\App\Http\Controllers\Admin\AdminDueCustomerController::class, 'show'])->name('admin.due-customers.show');
    Route::post('/due-customers/collect', [\App\Http\Controllers\Admin\AdminDueCustomerController::class, 'collectPayment'])->name('admin.due-customers.collect');

    // Reports: Cash Statement & Closing
    Route::get('/reports/cash-statement', [\App\Http\Controllers\Admin\AdminReportController::class, 'cashStatement'])->name('admin.reports.cash-statement');
});

